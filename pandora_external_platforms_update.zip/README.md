# Anime Code Adventures LMS

> **Version**: 3.0.0  
> **Type**: Gamified Local Learning Management System  
> **Architecture**: FastAPI + SQLite Backend | Single-File HTML Clients  
> **Accessibility**: WCAG AAA Compliant

---

## 🎮 Overview

**Code Adventures** — гейммифицированная LMS для обучения программированию. Превращает стандартные задачи в RPG-квесты с XP, уровнями и tier-системой сложности.

### Ключевые особенности

| Feature | Description |
|---------|-------------|
| **Zero Config** | Клиенты автоматически ищут сервер в локальной сети |
| **Client-Side Execution** | Python (Pyodide) и JS выполняются в браузере |
| **Secure Auth** | bcrypt пароли + JWT токены с 24h expiration |
| **Rate Limiting** | Защита от брутфорса (5 попыток/минуту) |
| **22 Achievements** | Система достижений с XP бонусами и редкостью |
| **Admin Panel** | Отдельный интерфейс для учителя |
| **WCAG AAA** | Контраст 7:1, фокус-индикаторы, ARIA-метки |

---

## 📁 Структура проекта

```
PANDORA/
├── index.html      # Клиент для учеников
├── admin.html      # Панель учителя
├── main.py         # FastAPI сервер + SQLite
├── tasks.json      # База квестов
├── requirements.txt
├── academy.db      # SQLite (создается автоматически)
└── README.md
```

---

## 🚀 Быстрый старт

### 1. Установка зависимостей
```bash
cd /home/qarrooak/Documents/PANDORA
pip install -r requirements.txt
```

### 2. Запуск сервера (Учитель)
```bash
python3 main.py
```

При запуске сервер покажет:
```
═══════════════════════════════════════════════════════════
  ⚔️  ANIME CODE ADVENTURES - SENSEI NODE v2.0
═══════════════════════════════════════════════════════════

  📡  Server:  http://192.168.X.X:8000
  🔑  Admin:   admin / admin123

  📋  Tell students to enter IP: 192.168.X.X
```

### 3. Вход в Admin Panel (Учитель)
1. Открыть `admin.html` в браузере
2. Ввести `admin` / `admin123`
3. Создать аккаунты для учеников

### 4. Подключение учеников
1. Раздать файл `index.html`
2. Ученики открывают его в браузере
3. Вводят логин/пароль созданные учителем
4. (Опционально) Вводят IP сервера если автоскан не сработал

---

## 👥 Роли пользователей

| Роль | Доступ | Логин по умолчанию |
|------|--------|-------------------|
| **Admin** | Создание учеников, просмотр прогресса, ревью Scratch | `admin` / `admin123` |
| **Student** | Прохождение квестов, XP, уровни | Создается админом |

---

## 📋 API Endpoints

### Публичные
| Endpoint | Описание |
|----------|----------|
| `GET /ping` | Auto-discovery для клиентов |
| `GET /api/tasks` | Список всех квестов |

### Авторизация
| Endpoint | Описание |
|----------|----------|
| `POST /api/auth/login` | Вход (возвращает token) |
| `GET /api/auth/me` | Текущий пользователь |
| `POST /api/auth/logout` | Выход |

### Прогресс (требует token)
| Endpoint | Описание |
|----------|----------|
| `POST /api/progress/complete` | Отметить квест выполненным |
| `POST /api/progress/submit` | Отправить Scratch на ревью |

### Администрирование (требует admin role)
| Endpoint | Описание |
|----------|----------|
| `GET /api/admin/users` | Список всех пользователей |
| `POST /api/admin/users` | Создать ученика |
| `DELETE /api/admin/users/{id}` | Удалить ученика |
| `GET /api/admin/submissions` | Scratch-ссылки на проверку |
| `PUT /api/admin/submissions/{id}` | Одобрить/отклонить с оценкой (0-10) |
| `GET /api/admin/stats` | Статистика системы |
| `GET /api/admin/backup/sqlite` | Скачать SQLite backup (admin-only) |
| `GET /api/admin/priorities/{user_id}` | Приоритеты обучения |
| `PUT /api/admin/priorities/{user_id}` | Установить приоритеты |
| `POST /api/admin/rewards` | Выдать награду |
| `GET /api/admin/rewards/{user_id}` | История наград |
| `GET /api/admin/users/{user_id}/completions` | История заданий с кодом |
| `PUT /api/admin/completions/{id}/adjust` | Пересмотр XP (0-10) |
| `GET /api/admin/progress` | Данные для графика XP |

### Профиль ученика
| Endpoint | Описание |
|----------|----------|
| `GET /api/profile` | Полный профиль с аватаром |
| `PUT /api/profile` | Обновить имя/аватар |
| `GET /api/user/submissions` | Мои отправленные работы |
| `GET /api/user/rewards` | Мои награды |
| `GET /api/user/achievements` | Мои достижения |

### Достижения
| Endpoint | Описание |
|----------|----------|
| `GET /api/achievements` | Все доступные достижения |
| `GET /api/user/achievements` | Разблокированные достижения пользователя |

---

## 🎯 Tier-система квестов

| Tier | Сложность | XP |
|------|-----------|-----|
| **D** | Beginner | 10-15 |
| **C** | Basic | 30-40 |
| **B** | Intermediate | 50-60 |
| **A** | Advanced | 70-80 |

---

## 🖥️ Admin Panel v2.0

### Новые секции
| Секция | Описание |
|--------|----------|
| **📜 История** | Просмотр выполненных заданий с кодом, пересмотр XP |
| **📈 Прогресс** | Chart.js график XP по времени (один/все ученики) |
| **🎯 Приоритеты** | Распределение заданий по категориям (%) |
| **🏅 Награды** | Выдача кастомных наград с иконками |

### Улучшенный Review
- Оценка 0-10 с preview XP (`XP = max_xp × score/10`)
- Скачивание `.sb3` файлов напрямую
- Feedback видимый ученику

---

## 👤 Профиль ученика

| Функция | Описание |
|---------|----------|
| **Аватар** | Загрузка и сохранение фото профиля |
| **Мои награды** | История полученных наград |
| **Мои работы** | Статус отправленных заданий |
| **Выход** | Кнопка logout в профиле |
| **Галочки** | Выполненные задания отмечаются ✓ |

---

## 🧪 Добавление квестов

Редактировать `tasks.json`:

```json
{
  "id": "unique_id",
  "category": "python",
  "tier": "C",
  "xp": 100,
  "title": "Quest Title",
  "story": "Narrative setup...",
  "description": "Technical task",
  "initial_code": "# starter code",
  "check_logic": {
    "engine": "pyodide",
    "cases": [
      { "code": "function(5)", "expected": 10 }
    ]
  }
}
```

---

## ♿ Accessibility (WCAG AAA)

- **Контраст**: Минимум 7:1 для всего текста
- **Focus**: Видимые индикаторы фокуса (3px outline)
- **Skip Link**: Пропуск навигации для screen readers
- **ARIA**: Правильные roles и labels
- **Keyboard**: Полная навигация с клавиатуры

---

## ⚠️ Технические заметки

1. **CORS**: `allow_origins=["*"]` для работы с `file://`
2. **SQLite**: База `academy.db` создается автоматически
3. **Pyodide**: Загружается с CDN (нужен интернет при первом запуске)
4. **Сессии**: Хранятся в БД, token в localStorage клиента

### Таблицы БД v2.0
| Таблица | Назначение |
|---------|------------|
| `users` | Пользователи (username, xp, level) |
| `completed_tasks` | Выполненные задания + solution + xp_earned |
| `submissions` | Scratch на проверку + score |
| `user_priorities` | Приоритеты обучения по категориям |
| `rewards` | Награды выданные админом |
| `xp_log` | Лог всех изменений XP (для графиков) |
| `user_stats` | Статистика + avatar_data |

---

## 📜 License

MIT — свободное использование в образовательных целях.
# pandora

---

## Маркировка задач Codewars и LeetCode

В эту сборку добавлен внешний пакет `external_platforms_all_available_20260514`. Задачи из Codewars и LeetCode остаются в обычных категориях `python` и `javascript`, но дополнительно имеют платформенную маркировку.

### Основные поля

```json
"source_platform": "codewars"
```

или:

```json
"source_platform": "leetcode"
```

У каждой внешней задачи также есть:

```json
"source_pack": "external_platforms_all_available_20260514",
"source_repository": "uploaded:...zip",
"source_path": "...",
"source_title": "...",
"source_slug": "...",
"source_difficulty": "Easy | Medium | Hard | null"
```

### Теги платформ

Codewars-задачи помечаются тегом:

```json
"platform:codewars"
```

LeetCode-задачи помечаются тегом:

```json
"platform:leetcode"
```

Общие теги внешнего пакета:

```json
"source:external",
"source:codewars",
"source:leetcode",
"lang:python",
"lang:javascript",
"xp_scale:external_300_2000"
```

### Фильтрация во фронтенде

```js
const codewarsTasks = tasks.filter(t => t.tags?.includes('platform:codewars'));
const leetcodeTasks = tasks.filter(t => t.tags?.includes('platform:leetcode'));

const pythonLeetCode = tasks.filter(
  t => t.category === 'python' && t.source_platform === 'leetcode'
);

const jsCodewars = tasks.filter(
  t => t.category === 'javascript' && t.source_platform === 'codewars'
);
```

### XP внешних задач

Для внешних задач используется отдельная шкала `300–2000 XP`. Она намеренно выше старой локальной шкалы, чтобы Codewars/LeetCode-задачи можно было показывать как отдельный продвинутый трек. Маркер шкалы: `xp_scale:external_300_2000`.

### Что не добавлялось

В пакет не включались задачи, которые нельзя безопасно и честно адаптировать под текущий автопроверяемый контракт: premium/locked LeetCode, задачи с кастомными API (`TreeNode`, `ListNode`, `NestedInteger`, `Robot`, `read4` и подобные), сетевой scraping, внешние зависимости, задачи без простой функции или без минимум двух сериализуемых эталонных тестов. Подробный список причин находится в `external_platforms_manifest.json`.
